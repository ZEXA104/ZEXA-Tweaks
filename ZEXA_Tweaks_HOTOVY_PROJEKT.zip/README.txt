ZEXA Tweaks v2

1. Rozbal ZIP.
2. Pravym tlacitkem klikni na START_ZEXA_TWEAKS.bat.
3. Vyber Spustit jako spravce.
4. Vyber funkci.

Pokud Windows SmartScreen upozorni na neznamou aplikaci, neni to podepsany komercni program.
Tato verze je PowerShell aplikace a zdrojovy kod je primo v souboru ZEXA_Tweaks.ps1.

Pred zmenami se aplikace pokusi vytvorit bod obnoveni a registry backup.
Network Tweaks vyzaduji restart.
