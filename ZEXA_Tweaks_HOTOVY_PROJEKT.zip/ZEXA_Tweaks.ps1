Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$backupDir = Join-Path $env:USERPROFILE "ZEXA_Tweaks_Backup"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null

function IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (IsAdmin)) {
    [System.Windows.Forms.MessageBox]::Show(
        "Spust tento program jako spravce.`r`nPrave tlacitko > Spustit jako spravce.",
        "ZEXA Tweaks"
    )
    exit
}

function WriteLog([string]$text) {
    if ($script:logBox) {
        $script:logBox.AppendText("[$(Get-Date -Format HH:mm:ss)] $text`r`n")
        $script:logBox.ScrollToCaret()
    }
}

function MakeBackup {
    try {
        Checkpoint-Computer -Description "ZEXA Tweaks" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
        WriteLog "OK: Bod obnoveni vytvoren."
    } catch {
        WriteLog "INFO: Bod obnoveni nebyl vytvoren. Windows muze mit ochranu systemu vypnutou."
    }
}

function OptimizeWindows {
    MakeBackup

    try {
        $p1 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR"
        $p2 = "HKCU:\System\GameConfigStore"

        if (Test-Path $p1) {
            reg.exe export "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" (Join-Path $backupDir "GameDVR.reg") /y | Out-Null
            New-ItemProperty -Path $p1 -Name "AppCaptureEnabled" -Value 0 -PropertyType DWord -Force | Out-Null
        }

        if (Test-Path $p2) {
            reg.exe export "HKCU\System\GameConfigStore" (Join-Path $backupDir "GameConfigStore.reg") /y | Out-Null
            New-ItemProperty -Path $p2 -Name "GameDVR_Enabled" -Value 0 -PropertyType DWord -Force | Out-Null
        }

        WriteLog "OK: Game DVR capture vypnuto."
    } catch {
        WriteLog "WARNING: Game DVR se nepodarilo upravit."
    }

    CleanTemp
    WriteLog "HOTOVO: Windows optimize."
}

function GamingTweaks {
    MakeBackup
    try {
        $p = "HKCU:\Software\Microsoft\GameBar"
        New-Item -Path $p -Force | Out-Null
        New-ItemProperty -Path $p -Name "AllowAutoGameMode" -Value 1 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $p -Name "AutoGameModeEnabled" -Value 1 -PropertyType DWord -Force | Out-Null
        WriteLog "OK: Windows Game Mode zapnut."
    } catch {
        WriteLog "WARNING: Game Mode se nepodarilo nastavit."
    }
}

function InputTweaks {
    MakeBackup
    try {
        reg.exe export "HKCU\Control Panel\Mouse" (Join-Path $backupDir "Mouse.reg") /y | Out-Null
        $p = "HKCU:\Control Panel\Mouse"
        Set-ItemProperty -Path $p -Name "MouseSpeed" -Value "0"
        Set-ItemProperty -Path $p -Name "MouseThreshold1" -Value "0"
        Set-ItemProperty -Path $p -Name "MouseThreshold2" -Value "0"
        WriteLog "OK: Mouse acceleration vypnuta."
        WriteLog "INFO: Mozna bude potreba odhlasit/prihlasit Windows."
    } catch {
        WriteLog "WARNING: Mouse tweak se nepodaril."
    }
}

function NetworkTweaks {
    MakeBackup
    ipconfig /flushdns | Out-Null
    netsh winsock reset | Out-Null
    WriteLog "OK: DNS cache vycistena."
    WriteLog "OK: Winsock resetovan."
    WriteLog "INFO: Pro dokonceni restartuj PC."
}

function CleanTemp {
    try {
        Remove-Item -Path (Join-Path $env:TEMP "*") -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path (Join-Path $env:WINDIR "Temp\*") -Recurse -Force -ErrorAction SilentlyContinue
        WriteLog "OK: Docasne soubory vycisteny."
    } catch {
        WriteLog "INFO: Nektere docasne soubory jsou prave pouzivane."
    }
}

function SystemInfo {
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $ramTotal = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    $ramFree = [math]::Round($os.FreePhysicalMemory / 1MB, 1)

    WriteLog "===== SYSTEM INFO ====="
    WriteLog "Windows: $($os.Caption)"
    WriteLog "Verze: $($os.Version)"
    WriteLog "CPU: $($cpu.Name)"
    WriteLog "RAM: $ramTotal GB celkem / $ramFree GB volno"
    WriteLog "Backup slozka: $backupDir"
}

function RestoreBackups {
    if (-not (Test-Path $backupDir)) {
        WriteLog "INFO: Zadne backupy nebyly nalezeny."
        return
    }

    $files = Get-ChildItem -Path $backupDir -Filter "*.reg" -ErrorAction SilentlyContinue
    if (-not $files) {
        WriteLog "INFO: Zadne registry backupy nebyly nalezeny."
        return
    }

    foreach ($file in $files) {
        reg.exe import $file.FullName | Out-Null
        WriteLog "OK: Obnoven $($file.Name)"
    }

    WriteLog "HOTOVO: Restartuj PC."
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "ZEXA Tweaks"
$form.Size = New-Object System.Drawing.Size(780, 590)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(18,18,18)
$form.ForeColor = [System.Drawing.Color]::White
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false

$title = New-Object System.Windows.Forms.Label
$title.Text = "ZEXA TWEAKS"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 24, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(25, 18)
$title.AutoSize = $true
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Windows 11 Gaming Utility"
$subtitle.ForeColor = [System.Drawing.Color]::Silver
$subtitle.Location = New-Object System.Drawing.Point(29, 60)
$subtitle.AutoSize = $true
$form.Controls.Add($subtitle)

function NewTweakButton([string]$text, [int]$y, [scriptblock]$action) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $text
    $button.Size = New-Object System.Drawing.Size(220, 48)
    $button.Location = New-Object System.Drawing.Point(25, $y)
    $button.FlatStyle = "Flat"
    $button.BackColor = [System.Drawing.Color]::FromArgb(35,35,35)
    $button.ForeColor = [System.Drawing.Color]::White
    $button.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $button.Add_Click($action)
    $form.Controls.Add($button)
}

NewTweakButton "Optimize Windows" 100 { OptimizeWindows }
NewTweakButton "Gaming Tweaks" 158 { GamingTweaks }
NewTweakButton "Input Tweaks" 216 { InputTweaks }
NewTweakButton "Network Tweaks" 274 { NetworkTweaks }
NewTweakButton "Clean TEMP" 332 { CleanTemp }
NewTweakButton "System Info" 390 { SystemInfo }
NewTweakButton "Restore Backups" 448 { RestoreBackups }

$script:logBox = New-Object System.Windows.Forms.TextBox
$script:logBox.Multiline = $true
$script:logBox.ReadOnly = $true
$script:logBox.ScrollBars = "Vertical"
$script:logBox.BackColor = [System.Drawing.Color]::FromArgb(10,10,10)
$script:logBox.ForeColor = [System.Drawing.Color]::LightGray
$script:logBox.Location = New-Object System.Drawing.Point(265, 100)
$script:logBox.Size = New-Object System.Drawing.Size(485, 396)
$script:logBox.Font = New-Object System.Drawing.Font("Consolas", 9)
$form.Controls.Add($script:logBox)

$note = New-Object System.Windows.Forms.Label
$note.Text = "Backupy: %USERPROFILE%\ZEXA_Tweaks_Backup"
$note.ForeColor = [System.Drawing.Color]::Gray
$note.Location = New-Object System.Drawing.Point(270, 515)
$note.AutoSize = $true
$form.Controls.Add($note)

WriteLog "ZEXA Tweaks pripraven."
WriteLog "Spusteno jako spravce."
WriteLog "Vyber tweak vlevo."

[void]$form.ShowDialog()
