using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace ZEXA_Tweaks;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

public class MainForm : Form
{
    readonly Panel sidebar = new();
    readonly Panel content = new();
    readonly TextBox log = new();
    readonly Label title = new();

    static readonly Color Bg = Color.FromArgb(15,15,18);
    static readonly Color Panel = Color.FromArgb(23,23,28);
    static readonly Color Button = Color.FromArgb(32,32,38);

    public MainForm()
    {
        Text = "ZEXA Tweaks";
        Size = new Size(950,600);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Bg;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;

        sidebar.Dock = DockStyle.Left;
        sidebar.Width = 230;
        sidebar.BackColor = Panel;
        Controls.Add(sidebar);

        var logo = new Label {
            Text = "ZEXA\nTWEAKS",
            Font = new Font("Segoe UI",22,FontStyle.Bold),
            Location = new Point(25,25),
            Size = new Size(180,75),
            ForeColor = Color.White
        };
        sidebar.Controls.Add(logo);

        AddMenu("Dashboard",120,Dashboard);
        AddMenu("FPS Tweaks",175,Fps);
        AddMenu("Input Tweaks",230,Input);
        AddMenu("Network",285,Network);
        AddMenu("Windows",340,Windows);
        AddMenu("Cleaner",395,Cleaner);

        content.Dock = DockStyle.Fill;
        content.BackColor = Bg;
        Controls.Add(content);

        title.Font = new Font("Segoe UI",26,FontStyle.Bold);
        title.Location = new Point(30,25);
        title.AutoSize = true;
        content.Controls.Add(title);

        log.Multiline = true;
        log.ReadOnly = true;
        log.ScrollBars = ScrollBars.Vertical;
        log.BackColor = Color.FromArgb(9,9,11);
        log.ForeColor = Color.LightGray;
        log.Font = new Font("Consolas",10);
        log.Location = new Point(30,100);
        log.Size = new Size(650,350);
        content.Controls.Add(log);

        Dashboard();
    }

    void AddMenu(string text,int y,Action action)
    {
        var b = new Button {
            Text = text,
            Location = new Point(15,y),
            Size = new Size(200,45),
            FlatStyle = FlatStyle.Flat,
            BackColor = Button,
            ForeColor = Color.White,
            Font = new Font("Segoe UI",10,FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };
        b.FlatAppearance.BorderSize = 0;
        b.Click += (_,_) => action();
        sidebar.Controls.Add(b);
    }

    void ClearActions()
    {
        foreach (Control c in content.Controls)
            if (c != title && c != log) c.Dispose();
    }

    void ActionButton(string text,int x,int y,Action action)
    {
        var b = new Button {
            Text=text,
            Location=new Point(x,y),
            Size=new Size(250,48),
            FlatStyle=FlatStyle.Flat,
            BackColor=Button,
            ForeColor=Color.White,
            Font=new Font("Segoe UI",10,FontStyle.Bold)
        };
        b.FlatAppearance.BorderSize=0;
        b.Click += (_,_) => action();
        content.Controls.Add(b);
    }

    void Dashboard()
    {
        ClearActions();
        title.Text="Dashboard";
        log.Clear();
        Log("ZEXA Tweaks spuštěno.");
        Log("Windows 11 Gaming Utility");
        Log("");
        Log("Vyber kategorii vlevo.");
    }

    void Fps()
    {
        ClearActions(); title.Text="FPS Tweaks"; log.Clear();
        ActionButton("Enable Game Mode",30,100,GameMode);
        ActionButton("High Performance",300,100,HighPerformance);
        Log("Základní gaming nastavení.");
    }

    void Input()
    {
        ClearActions(); title.Text="Input Tweaks"; log.Clear();
        ActionButton("Disable Mouse Acceleration",30,100,MouseAcceleration);
        Log("Vypnutí Windows mouse acceleration.");
    }

    void Network()
    {
        ClearActions(); title.Text="Network"; log.Clear();
        ActionButton("Flush DNS",30,100,FlushDns);
        ActionButton("Reset Winsock",300,100,ResetWinsock);
    }

    void Windows()
    {
        ClearActions(); title.Text="Windows Optimization"; log.Clear();
        ActionButton("Optimize Windows",30,100,Optimize);
        Log("Bezpečné základní úpravy.");
    }

    void Cleaner()
    {
        ClearActions(); title.Text="Cleaner"; log.Clear();
        ActionButton("Clean TEMP",30,100,CleanTemp);
    }

    void Log(string s) => log.AppendText($"[{DateTime.Now:HH:mm:ss}] {s}\r\n");

    void Run(string file,string args)
    {
        try {
            Process.Start(new ProcessStartInfo {
                FileName=file, Arguments=args, UseShellExecute=true, Verb="runas",
                CreateNoWindow=true
            });
            Log("✓ Příkaz spuštěn.");
        } catch {
            Log("✗ Operace zrušena nebo bez oprávnění správce.");
        }
    }

    void GameMode()
    {
        Run("powershell","-NoProfile -Command \"New-Item -Path 'HKCU:\\Software\\Microsoft\\GameBar' -Force | Out-Null; Set-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\GameBar' -Name AllowAutoGameMode -Value 1 -Type DWord\"");
        Log("✓ Game Mode nastaven.");
    }

    void HighPerformance()
    {
        Run("powercfg","/setactive SCHEME_MIN");
        Log("✓ High Performance nastaven.");
    }

    void MouseAcceleration()
    {
        Run("reg","add \"HKCU\\Control Panel\\Mouse\" /v MouseSpeed /t REG_SZ /d 0 /f");
        Run("reg","add \"HKCU\\Control Panel\\Mouse\" /v MouseThreshold1 /t REG_SZ /d 0 /f");
        Run("reg","add \"HKCU\\Control Panel\\Mouse\" /v MouseThreshold2 /t REG_SZ /d 0 /f");
        Log("✓ Mouse acceleration vypnuta.");
    }

    void FlushDns()
    {
        Run("ipconfig","/flushdns");
        Log("✓ DNS cache vyčištěna.");
    }

    void ResetWinsock()
    {
        Run("netsh","winsock reset");
        Log("✓ Winsock resetován. Restartuj PC.");
    }

    void Optimize()
    {
        GameMode();
        CleanTemp();
        Log("✓ Optimalizace dokončena.");
    }

    void CleanTemp()
    {
        Run("powershell","-NoProfile -Command \"Remove-Item $env:TEMP\\* -Recurse -Force -ErrorAction SilentlyContinue\"");
        Log("✓ TEMP čištění spuštěno.");
    }
}
